package com.example.recyclerapplication

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class detail_mahasiswa : AppCompatActivity() {

    companion object {
        const val EXTRA_detail = "extra_detail"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_mhs)
        val imageView: ImageView = findViewById(R.id.detail_image)
        val detailNama: TextView = findViewById(R.id.tv_detail)
        val detailDeskripsi: TextView = findViewById(R.id.detail_deskripsi)

        val intent = intent.getParcelableExtra<Mahasiswa>(EXTRA_detail)

        Glide.with(this).load(intent?.photo).into(imageView)
        detailNama.text = intent?.name
        detailDeskripsi.text = intent?.detail
    }
}
