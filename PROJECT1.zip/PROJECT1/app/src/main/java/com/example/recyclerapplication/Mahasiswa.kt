package com.example.recyclerapplication

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
@Parcelize
data class Mahasiswa(
    var photo:Int = 0,
    var name:String = "",
    var detail:String = ""
) : Parcelable