package com.example.recyclerapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerapplication.detail_mahasiswa.Companion.EXTRA_detail

class MainActivity : AppCompatActivity() {
    private lateinit var rvMahasiswa: RecyclerView
    private var list: ArrayList<Mahasiswa> = arrayListOf()
    private var title: String = "Mode List"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setActionBarTitle(title)
        rvMahasiswa = findViewById(R.id.rv_mahasiswa)
        rvMahasiswa.setHasFixedSize(true)

        list.addAll(MahasiswaData.listData)
        showRecycleList()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when(selectedMode){
            R.id.menu_list->{
                title = "Mode List"
                showRecycleList()
            }
            R.id.menu_grid->{
                title = "Mode Grid"
                showRecycleGrid()
            }
            R.id.menu_card->{
                title = "Mode Card"
                showRecycleCard()
            }
        }
    }



    private fun showRecycleList() {
        rvMahasiswa.layoutManager = LinearLayoutManager(this)
        val listMahasiswaAdapter = ListMhsAdapter(list)
        rvMahasiswa.adapter = listMahasiswaAdapter

        listMahasiswaAdapter.setOnItemClickCallback(object : ListMhsAdapter.OnItemClickCallback{
            override fun onItemClicked(data : Mahasiswa) {
                val itemMahasiswa = Mahasiswa (
                    data.photo,
                    data.name,
                    data.detail
                )
                val intent = Intent(this@MainActivity, detail_mahasiswa::class.java)
                intent.putExtra(EXTRA_detail, itemMahasiswa)
                startActivity(intent)
                showSelectedMahasiswa(data)
            }
        })
    }

    private fun showRecycleGrid() {
        rvMahasiswa.layoutManager = GridLayoutManager(this,2)
        val gridMahasiswaAdapter = GridMhsAdapter(list)
        rvMahasiswa.adapter = gridMahasiswaAdapter

        gridMahasiswaAdapter.setOnItemClickCallback(object : GridMhsAdapter.OnItemClickCallback{
            override fun onItemClicked(data: Mahasiswa) {
                val itemMahasiswa = Mahasiswa (
                    data.photo,
                    data.name,
                    data.detail
                )
                val intent = Intent(this@MainActivity, detail_mahasiswa::class.java)
                intent.putExtra(EXTRA_detail, itemMahasiswa)
                startActivity(intent)
                showSelectedMahasiswa(data)
            }
        })
    }

    private fun showRecycleCard() {
        rvMahasiswa.layoutManager = LinearLayoutManager(this)
        val cardMahasiswaAdapter = CardMhsAdapter(list)
        rvMahasiswa.adapter = cardMahasiswaAdapter

        cardMahasiswaAdapter.setOnItemClickCallback(object : CardMhsAdapter.OnItemClickCallback{
            override fun onItemClicked(data: Mahasiswa) {
                val itemMahasiswa = Mahasiswa (
                    data.photo,
                    data.name,
                    data.detail
                )
                val intent = Intent(this@MainActivity, detail_mahasiswa::class.java)
                intent.putExtra(EXTRA_detail, itemMahasiswa)
                startActivity(intent)
                showSelectedMahasiswa(data)
            }
        })
    }

    private fun setActionBarTitle(title: String) {
        supportActionBar?.title = title
    }

    private fun showSelectedMahasiswa(mahasiswa: Mahasiswa) {
        Toast.makeText(this, "You Choose " + mahasiswa.name, Toast.LENGTH_SHORT).show()
    }

}
