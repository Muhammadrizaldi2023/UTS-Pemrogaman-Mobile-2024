package com.example.recyclerapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

@Suppress("DEPRECATION")
class ListMhsAdapter(private val listMahasiswa: ArrayList<Mahasiswa>) : RecyclerView.Adapter<ListMhsAdapter.ListViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        var tvName: TextView = itemView.findViewById(R.id.tv_name)
        var tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_list_mhs, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val mahasiswa = listMahasiswa[position]
        Glide.with(holder.itemView.context)
            .load(mahasiswa.photo)
            .apply(RequestOptions().override(55, 55))
            .into(holder.imgPhoto)
        holder.tvName.text = mahasiswa.name
        holder.tvDetail.text = mahasiswa.detail
        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(listMahasiswa[holder.adapterPosition])
        }
    }

    override fun getItemCount(): Int {
        return listMahasiswa.size
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Mahasiswa)
    }
}
