package com.example.recyclerapplication

object MahasiswaData {
    private val mahasiswaNames = arrayOf(
        "Muhammad Rehan",
        "Muhammad Wahyu Nanda",
        "Andrian Juhandri",
        "Rismadin Rasid",
        "Michael Felix",
        "Muhammad Dimas Maulana",
        "Vincent Candi",
        "Muhammad Rivai",
        "Muhammad Ridwan",
        "Kahlil Gibran Saputra",
        "Andi Rachman Zikry",
        "Muhammad Rizaldi Nur"
    )

    private val mahasiswaDetails = arrayOf(
        "Muhammad Rehan Seorang mahasiswa yang aktif dalam kegiatan kemahasiswaan dan memiliki minat dalam bidang pengembangan aplikasi web.",
        "Andrian Juhandri Seorang mahasiswa yang memiliki minat dalam bidang jaringan komputer dan sering melakukan eksperimen dengan teknologi terbaru.",
        "Muhammad Wahyu Nanda Seorang mahasiswa yang memiliki minat dalam pengembangan perangkat lunak dan sering berpartisipasi dalam kompetisi pemrograman.",
        "Rismadin Rasid Seorang mahasiswa yang memiliki bakat dalam bidang seni dan desain, sering mengikuti workshop dan seminar terkait desain grafis.",
        "Michael Felix Seorang mahasiswa yang aktif dalam kegiatan olahraga dan memiliki minat dalam bidang kesehatan dan kebugaran.",
        "Muhammad Dimas Maulana Seorang mahasiswa yang memiliki minat dalam bidang keuangan dan investasi, sering mengikuti seminar-seminar tentang pasar modal.",
        "Vincent Candi Seorang mahasiswa yang aktif dalam kegiatan sosial dan kegiatan amal, memiliki minat dalam bidang konservasi lingkungan.",
        "Muhammad Rivai Seorang mahasiswa yang memiliki minat dalam bidang sejarah dan seni budaya, sering mengikuti festival budaya dan pameran seni.",
        "Muhammad Ridwan Seorang mahasiswa yang memiliki minat dalam bidang musik dan sering berpartisipasi dalam konser musik di kampus.",
        "Kahlil Gibran Saputra Seorang mahasiswa yang memiliki minat dalam bidang literatur dan sastra, sering menulis cerpen dan puisi.",
        "Andi Rachman Zikry Seorang mahasiswa yang aktif dalam kegiatan kepemimpinan dan organisasi, sering menjadi panitia dalam acara-acara kampus.",
        "Muhammad Rizaldi Nur Seorang mahasiswa yang memiliki minat dalam bidang teknologi informasi dan sering mengikuti pelatihan-pelatihan terkait pemrograman."
    )

    private val mahasiswaImages = intArrayOf(
        R.drawable.rehan,
        R.drawable.wahyu,
        R.drawable.andrian,
        R.drawable.rismadin,
        R.drawable.felix,
        R.drawable.dimas,
        R.drawable.vincent,
        R.drawable.rivai,
        R.drawable.ridwan,
        R.drawable.kahlil,
        R.drawable.andi,
        R.drawable.rizaldi
    )

    val listData: ArrayList<Mahasiswa>
        get() {
            val list = ArrayList<Mahasiswa>()
            for (position in mahasiswaNames.indices) {
                val mahasiswa = Mahasiswa()
                mahasiswa.name = mahasiswaNames[position]
                mahasiswa.detail = mahasiswaDetails[position]
                mahasiswa.photo = mahasiswaImages[position]
                list.add(mahasiswa)
            }
            return list
        }
}
